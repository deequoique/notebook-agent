export const CLIENT_VERSION = "0.1.3";
export async function sha256Hex(value) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
export async function contentHash(cues) {
    return sha256Hex(cues.map((cue) => `${cue.start_sec.toFixed(3)}\t${cue.end_sec.toFixed(3)}\t${cue.text.trim()}`).join("\n"));
}
export function captureRequest(capture) {
    const cues = capture.caption.cues;
    return contentHash(cues).then((content_hash) => ({
        protocol_version: "capture.v1",
        client_version: CLIENT_VERSION,
        ...capture,
        content_hash,
    }));
}
